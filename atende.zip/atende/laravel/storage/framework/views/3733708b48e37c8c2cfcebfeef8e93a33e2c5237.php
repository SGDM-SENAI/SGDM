<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('plugins.DatatablesPlugin', true); ?>

<?php $__env->startSection('title', 'Lista de Escolas'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo app('translator')->get('Escola :: lista'); ?></h1>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="card card-primary card-outline direct-chat direct-chat-primary shadow-none">
        <div class="card-header">        
            <div class="d-flex justify-content-between w-100">
                <h3 class="card-title">
                    <span><?php echo app('translator')->get('Lista de escolas'); ?></span>
                </h3>       
                <a href="<?php echo e(route('escola.create')); ?>" class="btn-danger btn-sm">
                    <i class="fa fa-plus"></i> <?php echo app('translator')->get('Adicionar'); ?>
                </a>
            </div>        
        </div>
        <div class="row"><p></p></div>
        <?php if(session('success')): ?>                
            <?php if (isset($component)) { $__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\Alert::class, ['icon' => 'fa fa-lg fa-thumbs-up','title' => 'Feito!','dismissable' => true] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-teal text-uppercase']); ?>
                <?php echo e(session('success')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4)): ?>
<?php $component = $__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4; ?>
<?php unset($__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong><?php echo app('translator')->get('Whoops!'); ?> </strong><?php echo app('translator')->get('Houve alguns problemas com sua entrada.'); ?> <br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <!-- /.card-header -->
        <!-- Table start -->
        
        
        <?php
        $heads = [
            'Código',
            'Nome da escola',
            ['label' => 'Rede de Ensino', 'width' => 40],
            ['label' => 'Ações', 'no-export' => true, 'width' => 5],
        ];

        $config['data'] = array();        
        foreach ($escolacases as $case) {
            array_push($config['data'], [$case->id, $case->nome_escola, $case->rede,]);
        }       
        $order = ['order' => [[1, 'asc']]];
        array_push($config, $order);
        $columns = ['columns' => [null, null, null, ['orderable' => false]]];
        array_push($config, $columns);
        
        //dd($config);
        ?>

        
        <?php if (isset($component)) { $__componentOriginal07fd598d67a9f344ba4b0a77ed63c2052b910f24 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Tool\Datatable::class, ['id' => 'table_escola','heads' => $heads,'headTheme' => 'dark','striped' => true,'hoverable' => true,'withButtons' => true] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Tool\Datatable::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    
            <?php $__currentLoopData = $config['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    //dd($row[0]);
                ?>
                <tr>
                    <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo $cell; ?></td>                      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td>
                        <nobr>
                            <form action="<?php echo e(route('escola.destroy', $row[0])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <a href="<?php echo e(route('escola.edit', $row[0])); ?>" class="btn btn-xs btn-default text-primary mx-1 shadow" title="Editar">
                                    <i class="fa fa-lg fa-fw fa-pen"></i>
                                </a>
                            
                                <button class="btn btn-xs btn-default text-danger mx-1 shadow" type="submit" title="Deletar">
                                    <i class="fa fa-lg fa-fw fa-trash"></i>
                                </button>                                
                                
                            </form>
                        </nobr>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal07fd598d67a9f344ba4b0a77ed63c2052b910f24)): ?>
<?php $component = $__componentOriginal07fd598d67a9f344ba4b0a77ed63c2052b910f24; ?>
<?php unset($__componentOriginal07fd598d67a9f344ba4b0a77ed63c2052b910f24); ?>
<?php endif; ?>    
    
    <!-- /.card-body -->    
    </div>

    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\atende\laravel\resources\views/escola/index.blade.php ENDPATH**/ ?>