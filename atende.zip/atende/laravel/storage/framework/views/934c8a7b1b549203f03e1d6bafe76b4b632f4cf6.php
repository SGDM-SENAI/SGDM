<?php $__env->startSection('title', 'Cadastro de Escola'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo app('translator')->get('Escola :: cadastro'); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card card-primary card-outline direct-chat direct-chat-primary shadow-none">
    <div class="card-header">        
        <div class="d-flex justify-content-between w-100">
            <h3 class="card-title">
                <span><?php echo app('translator')->get('Formulário de atualização de Escola'); ?></span>
            </h3>       
            <a href="<?php echo e(route('escola.index')); ?>" class="btn-danger btn-sm">
                <i class="fa fa-arrow-left"></i> <?php echo app('translator')->get('Voltar'); ?>
            </a>
        </div>        
    </div>
    <div class="row"><p></p></div>
        <?php if(session('success')): ?>                
            <?php if (isset($component)) { $__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\Alert::class, ['icon' => 'fa fa-lg fa-thumbs-up','title' => 'Feito!','dismissable' => true] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-teal text-uppercase']); ?>
                <?php echo e(session('success')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4)): ?>
<?php $component = $__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4; ?>
<?php unset($__componentOriginal08391688e03353529fc1a5ef6a24130dfd496ae4); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong><?php echo app('translator')->get('Whoops!'); ?> </strong><?php echo app('translator')->get('Houve alguns problemas com sua entrada.'); ?> <br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    <!-- /.card-header -->
    <!-- form start -->
    <form action="<?php echo e(route('escola.update', $escolacase->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="card-body">
            <div class="form-group">
                <?php if (isset($component)) { $__componentOriginal7d1474369c7a69c75ad2fc0edfd903b7880af2ff = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Form\Input::class, ['name' => 'nome_escola','label' => 'Nome da escola','fgroupClass' => 'col-md'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($escolacase->nome_escola).'','placeholder' => 'Informe o nome da escola a ser atualizada.','required' => 'required','enable-feedback' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d1474369c7a69c75ad2fc0edfd903b7880af2ff)): ?>
<?php $component = $__componentOriginal7d1474369c7a69c75ad2fc0edfd903b7880af2ff; ?>
<?php unset($__componentOriginal7d1474369c7a69c75ad2fc0edfd903b7880af2ff); ?>
<?php endif; ?>          
            </div>
            <div class="form-group">     
            <?php
                //dd($Escolacase->localidade);
            ?>              
            <?php if (isset($component)) { $__componentOriginal325d3d6934803fba81e0289d299b9960546803c2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Form\Select::class, ['name' => 'rede','label' => 'Rede de ensino'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Informe a rede de ensino da escola.']); ?>
                <option <?php if($escolacase->rede == "MUNICIPAL"): ?>
                        <?php echo e("selected='selected'"); ?> 
                <?php endif; ?> value="MUNICIPAL">MUNICIPAL</option>
                <option <?php if($escolacase->rede == "ESTADUAL"): ?>
                    <?php echo e("selected='selected'"); ?> 
                <?php endif; ?> value="ESTADUAL">ESTADUAL</option>
                <option <?php if($escolacase->rede == "FEDERAL"): ?>
                    <?php echo e("selected='selected'"); ?> 
                <?php endif; ?> value="FEDERAL">FEDERAL</option>
                <option <?php if($escolacase->rede == "PRIVADA"): ?>
                    <?php echo e("selected='selected'"); ?> 
                <?php endif; ?> value="PRIVADA">PRIVADA</option>
                
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal325d3d6934803fba81e0289d299b9960546803c2)): ?>
<?php $component = $__componentOriginal325d3d6934803fba81e0289d299b9960546803c2; ?>
<?php unset($__componentOriginal325d3d6934803fba81e0289d299b9960546803c2); ?>
<?php endif; ?>    
            </div>                
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
            <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('Atualizar'); ?></button>
        </div>
        
    </form>
  </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\atende\laravel\resources\views/escola/edit.blade.php ENDPATH**/ ?>